// ===== ESP MOSFETS =====
#include <WiFi.h>
#include <esp_now.h>

#define RET_VENTOSAS     16  // cmd 1
#define EXT_VENTOSAS     17  // cmd 2
#define EXT_PRENSA_VACIO 21  // cmd 3
#define RET_PRENSA_VACIO 22  // cmd 4
#define RET_SELLADO      23  // cmd 5
#define EXT_SELLADO      25  // cmd 6
#define SELLADO_TERMICO  26  // cmd 7
#define VACIO_BOLSA      27  // cmd 8

#define TIEMPO_PISTON   500
#define TIEMPO_SELLADO 28000  // sellado termico 5s segun secuencia
#define TIEMPO_VACIO   2000

typedef struct struct_message {
  char comando[16];
} struct_message;
struct_message mensajeRecibido;

struct PinTimer {
  int  pin;
  bool activo;
  unsigned long inicio;
  unsigned long duracion;
};

PinTimer timers[8] = {
  { RET_VENTOSAS,     false, 0, TIEMPO_PISTON  },
  { EXT_VENTOSAS,     false, 0, TIEMPO_PISTON  },
  { EXT_PRENSA_VACIO, false, 0, TIEMPO_PISTON  },
  { RET_PRENSA_VACIO, false, 0, TIEMPO_PISTON  },
  { RET_SELLADO,      false, 0, TIEMPO_PISTON  },
  { EXT_SELLADO,      false, 0, TIEMPO_PISTON  },
  { SELLADO_TERMICO,  false, 0, TIEMPO_SELLADO },
  { VACIO_BOLSA,      false, 0, TIEMPO_VACIO   }
};

void apagarTodas();
void activarPin(int indice);
void procesarComando(String comando);
String getNombre(int cmd);

void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  memcpy(&mensajeRecibido, incomingData, sizeof(mensajeRecibido));
  String cmd = String(mensajeRecibido.comando);
  cmd.trim(); cmd.toUpperCase();
  Serial.print("Recibido: "); Serial.println(cmd);
  procesarComando(cmd);
}

void activarPin(int indice) {
  int parOpuesto = -1;
  if      (indice == 0) parOpuesto = 1;
  else if (indice == 1) parOpuesto = 0;
  else if (indice == 2) parOpuesto = 3;
  else if (indice == 3) parOpuesto = 2;
  else if (indice == 4) parOpuesto = 5;
  else if (indice == 5) parOpuesto = 4;

  if (parOpuesto >= 0 && timers[parOpuesto].activo) {
    Serial.print("BLOQUEADO par opuesto: "); Serial.println(getNombre(indice+1));
    return;
  }
  digitalWrite(timers[indice].pin, HIGH);
  timers[indice].activo = true;
  timers[indice].inicio = millis();
  Serial.print("ON: "); Serial.print(getNombre(indice+1));
  Serial.print(" "); Serial.print(timers[indice].duracion); Serial.println("ms");
}

void procesarComando(String comando) {
  comando.trim(); comando.toUpperCase();
  if (comando == "RESET") {
    apagarTodas();
    activarPin(0);  // RET_VENTOSAS
    activarPin(3);  // RET_PRENSA_VACIO
    activarPin(4);  // RET_SELLADO
    Serial.println("RESET: retrayendo pistones");
  }
  else if (comando == "EMERGENCIA") {
    apagarTodas();
    Serial.println("EMERGENCIA");
  }
  else if (comando == "INICIAR") {
    Serial.println("INICIAR ignorado en mosfets");
  }
  else {
    int valor = comando.toInt();
    if (valor >= 1 && valor <= 8) activarPin(valor - 1);
  }
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < 8; i++) { pinMode(timers[i].pin, OUTPUT); }
  apagarTodas();

  WiFi.mode(WIFI_STA); WiFi.disconnect();
  Serial.print("MAC MOSFETS: "); Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) { Serial.println("Error ESP-NOW"); return; }
  esp_now_register_recv_cb(OnDataRecv);

  Serial.println("ESP MOSFETS lista.");
  Serial.println("1=RET_VNT 2=EXT_VNT 3=EXT_PRENSA 4=RET_PRENSA 5=RET_SEL 6=EXT_SEL 7=SELL_TERM 8=VACIO");
}

void loop() {
  for (int i = 0; i < 8; i++) {
    if (timers[i].activo && millis() - timers[i].inicio >= timers[i].duracion) {
      digitalWrite(timers[i].pin, LOW);
      timers[i].activo = false;
      Serial.print("OFF: "); Serial.println(getNombre(i+1));
    }
  }
  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    procesarComando(cmd);
  }
}

void apagarTodas() {
  for (int i = 0; i < 8; i++) {
    digitalWrite(timers[i].pin, LOW);
    timers[i].activo = false;
  }
  Serial.println("Todas apagadas");
}

String getNombre(int cmd) {
  switch (cmd) {
    case 1: return "RET_VENTOSAS";
    case 2: return "EXT_VENTOSAS";
    case 3: return "EXT_PRENSA_VACIO";
    case 4: return "RET_PRENSA_VACIO";
    case 5: return "RET_SELLADO";
    case 6: return "EXT_SELLADO";
    case 7: return "SELLADO_TERMICO";
    case 8: return "VACIO_BOLSA";
  }
  return "?";
}
