// ===== ESP CARRITO =====
#include <WiFi.h>
#include <esp_now.h>
#include <ESP32Servo.h>

// ---------------- SERVOS ----------------
Servo miServo1, miServo2;
const int servoPin1 = 33, servoPin2 = 25;
int posAbierto1 = 0,  posCerrado1 = 160;
int posAbierto2 = 0,  posCerrado2 = 160;

// ---------------- SENSOR BOLSA ----------------
const int sensorPin = 32;
unsigned long tiempoDeteccion = 0;
bool contandoTiempo = false;
bool servoCerrado   = false;

// ---------------- TB6612 Canal A+B (actuadores lineales) ----------------
const int PWM  = 26, IN2  = 27, IN1  = 14, STBY = 13;
const int PWMB = 18, BIN2 = 19, BIN1 = 23;

// ---------------- STEPPER 28BYJ-48 (pinza lineal) ----------------
#define STP_IN1 16
#define STP_IN2 17
#define STP_IN3 21
#define STP_IN4 22

const int stepDelay = 1;                     // ms entre pasos
const unsigned long tiempoMovimiento = 2500; // ms de duracion del movimiento

// Secuencia half-step
const int pasos[8][4] = {
  {1,0,0,0},{1,1,0,0},{0,1,0,0},{0,1,1,0},
  {0,0,1,0},{0,0,1,1},{0,0,0,1},{1,0,0,1}
};
int pasoActual = 0;

// Estado stepper no bloqueante
enum EstadoStepper { STP_IDLE, STP_MOVIENDO };
EstadoStepper estadoStepper = STP_IDLE;
int direccionStepper = 0;
unsigned long inicioStepper = 0;
unsigned long ultimoPasoStepper = 0;

// ---------------- MAC NEMAS ----------------
uint8_t macNemas[]   = { 0xB0, 0xCB, 0xD8, 0xE9, 0x02, 0x04 };

// ---------------- ESTRUCTURA ----------------
typedef struct struct_message {
  char comando[16];
} struct_message;
struct_message mensajeEnvio;
struct_message mensajeRecibido;
esp_now_peer_info_t peerInfo;

// ---------------- ACTUADORES ----------------
unsigned long tiempoMotor  = 0;
unsigned long tiempoLimite = 0;
bool motorActivo = false;

// ===================== STEPPER =====================
void aplicarPaso(int paso) {
  digitalWrite(STP_IN1, pasos[paso][0]);
  digitalWrite(STP_IN2, pasos[paso][1]);
  digitalWrite(STP_IN3, pasos[paso][2]);
  digitalWrite(STP_IN4, pasos[paso][3]);
}

void apagarStepper() {
  digitalWrite(STP_IN1, LOW); digitalWrite(STP_IN2, LOW);
  digitalWrite(STP_IN3, LOW); digitalWrite(STP_IN4, LOW);
}

void iniciarStepper(int dir) {
  direccionStepper  = dir;
  inicioStepper     = millis();
  ultimoPasoStepper = millis();
  estadoStepper     = STP_MOVIENDO;
  Serial.println(dir == 1 ? "STEPPER DERECHA" : "STEPPER IZQUIERDA");
}

void actualizarStepper() {
  if (estadoStepper == STP_IDLE) return;
  if (millis() - inicioStepper >= tiempoMovimiento) {
    apagarStepper();
    estadoStepper = STP_IDLE;
    Serial.println("STEPPER DETENIDO");
    return;
  }
  if (millis() - ultimoPasoStepper >= stepDelay) {
    ultimoPasoStepper = millis();
    pasoActual += direccionStepper;
    if (pasoActual > 7) pasoActual = 0;
    if (pasoActual < 0) pasoActual = 7;
    aplicarPaso(pasoActual);
  }
}

// ===================== SERVOS =====================
void abrirGrippers() {
  miServo1.write(posAbierto1);
  miServo2.write(posAbierto2);
  servoCerrado = false;
  Serial.println("GRIPPERS ABIERTOS");
}

void cerrarGrippers() {
  miServo1.write(posCerrado1);
  miServo2.write(posCerrado2);
  servoCerrado = true;
  Serial.println("GRIPPERS CERRADOS");
}

void semiAbrirGrippers() {
  miServo1.write(142);
  miServo2.write(142);
  Serial.println("GRIPPERS SEMI ABIERTOS");
}

// ===================== ACTUADORES =====================
void subirActuadores() {
  digitalWrite(STBY, HIGH);
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH); analogWrite(PWM, 255);
  digitalWrite(BIN1, LOW); digitalWrite(BIN2, HIGH); analogWrite(PWMB, 255);
  tiempoMotor  = millis();
  tiempoLimite = 10000;
  motorActivo  = true;
  Serial.println("SUBIENDO");
}

void bajarActuadores() {
  digitalWrite(STBY, HIGH);
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); analogWrite(PWM, 255);
  digitalWrite(BIN1, HIGH); digitalWrite(BIN2, LOW); analogWrite(PWMB, 255);
  tiempoMotor  = millis();
  tiempoLimite = 10000;
  motorActivo  = true;
  Serial.println("BAJANDO");
}

void detenerActuadores() {
  analogWrite(PWM, 0); analogWrite(PWMB, 0);
  digitalWrite(IN1, LOW);  digitalWrite(IN2, LOW);
  digitalWrite(BIN1, LOW); digitalWrite(BIN2, LOW);
  digitalWrite(STBY, LOW);
  motorActivo = false;
  Serial.println("DETENIDO");
}

// ===================== ENVIAR A NEMAS =====================
void enviarComando(const char* cmd) {
  strncpy(mensajeEnvio.comando, cmd, sizeof(mensajeEnvio.comando));
  mensajeEnvio.comando[sizeof(mensajeEnvio.comando) - 1] = '\0';
  esp_now_send(macNemas, (uint8_t *)&mensajeEnvio, sizeof(mensajeEnvio));
  Serial.print("-> NEMAS: "); Serial.println(cmd);
}

// ===================== PROCESAR =====================
void procesarComando(String comando) {
  comando.trim();
  comando.toUpperCase();
  if      (comando == "SUBIR")     { subirActuadores(); }
  else if (comando == "BAJAR")     { bajarActuadores(); }
  else if (comando == "STOP")      { detenerActuadores(); }
  else if (comando == "ABRIR")     { abrirGrippers(); }
  else if (comando == "CERRAR")    { cerrarGrippers(); }
  else if (comando == "SEMIABRIR") { semiAbrirGrippers(); }
  else if (comando == "STEP_DER")  { iniciarStepper(1); }
  else if (comando == "STEP_IZQ")  { iniciarStepper(-1); }
  else if (comando == "EMERGENCIA"){
    detenerActuadores();
    apagarStepper();
    estadoStepper = STP_IDLE;
    abrirGrippers();
    Serial.println("EMERGENCIA");
  }
  else if (comando == "RESET") {
    detenerActuadores();
    apagarStepper();
    estadoStepper = STP_IDLE;
    abrirGrippers();
    iniciarStepper(-1);
    Serial.println("RESET carrito");
  }
  else { Serial.println("Ignorado: " + comando); }
}

// ===================== CALLBACK =====================
void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  memcpy(&mensajeRecibido, incomingData, sizeof(mensajeRecibido));
  String comando = String(mensajeRecibido.comando);
  Serial.print("Recibido: "); Serial.println(comando);
  procesarComando(comando);
}

void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {}

// ===================== SETUP =====================
void setup() {
  Serial.begin(115200);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  Serial.print("MAC CARRITO: ");
  Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) { Serial.println("Error ESP-NOW"); return; }
  esp_now_register_recv_cb(OnDataRecv);
  esp_now_register_send_cb(OnDataSent);

  memset(&peerInfo, 0, sizeof(peerInfo));
  memcpy(peerInfo.peer_addr, macNemas, 6);
  peerInfo.channel = 0; peerInfo.encrypt = false;
  esp_now_add_peer(&peerInfo);

  miServo1.attach(servoPin1);
  miServo2.attach(servoPin2);
  abrirGrippers();

  pinMode(sensorPin, INPUT);
  pinMode(IN1, OUTPUT);  pinMode(IN2, OUTPUT);
  pinMode(PWM, OUTPUT);  pinMode(STBY, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(PWMB, OUTPUT);
  detenerActuadores();

  pinMode(STP_IN1, OUTPUT); pinMode(STP_IN2, OUTPUT);
  pinMode(STP_IN3, OUTPUT); pinMode(STP_IN4, OUTPUT);
  apagarStepper();

  Serial.println("ESP CARRITO lista.");
}

// ===================== LOOP =====================
void loop() {

  actualizarStepper();

  if (motorActivo && millis() - tiempoMotor >= tiempoLimite) {
    detenerActuadores();
    Serial.println("AUTO STOP");
  }

  bool sensor = digitalRead(sensorPin);
  if (!servoCerrado) {
    if (sensor == HIGH) {
      if (!contandoTiempo) {
        tiempoDeteccion = millis();
        contandoTiempo  = true;
        Serial.println("Bolsa detectada");
      }
      if (millis() - tiempoDeteccion >= 3000) {
        cerrarGrippers();
        contandoTiempo = false;
        enviarComando("CARRITO_LISTO");
        Serial.println("CARRITO_LISTO enviado a NEMAS");
      }
    } else {
      contandoTiempo = false;
    }
  }

  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    procesarComando(cmd);
  }

}