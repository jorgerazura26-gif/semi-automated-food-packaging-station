// ===== ESP VENTOSAS =====
#include <WiFi.h>
#include <esp_now.h>
#include <Adafruit_ADS1X15.h>
#include <Wire.h>

const int pumpPin  = 2;
const int valvePin = 5;

Adafruit_ADS1115 ads;
float pressure = 0.0f;
#define UMBRAL_SUCCION   -20.0f
#define TIEMPO_SOSTENIDO  1000

uint8_t macNemas[]   = { 0xB0, 0xCB, 0xD8, 0xE9, 0x02, 0x04 };

typedef struct struct_message {
  char comando[16];
} struct_message;
struct_message mensajeEnvio;
struct_message mensajeRecibido;
esp_now_peer_info_t peerInfo;

bool bombaActiva     = false;
bool umbralActivo    = false;
bool bolsaConfirmada = false;
unsigned long tiempoUmbral = 0;

void encenderBomba() {
  digitalWrite(valvePin, HIGH);
  analogWrite(pumpPin, 255);
  bombaActiva = true; bolsaConfirmada = false;
  umbralActivo = false; tiempoUmbral = 0;
  Serial.println("Bomba ON");
}

void apagarBomba() {
  analogWrite(pumpPin, 0);
  digitalWrite(valvePin, LOW);
  bombaActiva = false; bolsaConfirmada = false;
  umbralActivo = false; tiempoUmbral = 0;
  Serial.println("Bomba OFF");
}

void enviarComando(const char* cmd) {
  strncpy(mensajeEnvio.comando, cmd, sizeof(mensajeEnvio.comando));
  mensajeEnvio.comando[sizeof(mensajeEnvio.comando) - 1] = '\0';
  esp_now_send(macNemas, (uint8_t *)&mensajeEnvio, sizeof(mensajeEnvio));
  Serial.print("-> NEMAS: "); Serial.println(cmd);
}

void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {}

void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  memcpy(&mensajeRecibido, incomingData, sizeof(mensajeRecibido));
  String cmd = String(mensajeRecibido.comando);
  cmd.trim(); cmd.toUpperCase();
  Serial.print("Recibido: "); Serial.println(cmd);
  if      (cmd == "VNTON")      { encenderBomba(); }
  else if (cmd == "VNTOFF")     { apagarBomba(); }
  else if (cmd == "EMERGENCIA") { apagarBomba(); Serial.println("EMERGENCIA"); }
  else if (cmd == "RESET")      { apagarBomba(); }
}

void agregarPeer(uint8_t* mac) {
  memset(&peerInfo, 0, sizeof(peerInfo));
  memcpy(peerInfo.peer_addr, mac, 6);
  peerInfo.channel = 0; peerInfo.encrypt = false;
  esp_now_add_peer(&peerInfo);
}

void setup() {
  Serial.begin(115200);
  pinMode(pumpPin, OUTPUT); pinMode(valvePin, OUTPUT);
  analogWrite(pumpPin, 0);
  digitalWrite(valvePin, LOW);  // reposo: valvula abierta al sensor

  Wire.begin();
  if (!ads.begin()) { Serial.println("ERROR ADS1115"); while(1); }
  Serial.println("ADS1115 OK");

  WiFi.mode(WIFI_STA); WiFi.disconnect();
  Serial.print("MAC VENTOSAS: "); Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) { Serial.println("Error ESP-NOW"); return; }
  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);
  agregarPeer(macNemas);

  Serial.println("ESP VENTOSAS lista.");
}

void loop() {
  int16_t adc0 = ads.readADC_SingleEnded(0);
  float volts  = ads.computeVolts(adc0);
  pressure     = (100.0f * volts) - 150.0f;

  if (bombaActiva && !bolsaConfirmada) {
    if (pressure <= UMBRAL_SUCCION) {
      if (!umbralActivo) {
        umbralActivo = true;
        tiempoUmbral = millis();
        Serial.println("Umbral -20kPa, contando 1s...");
      } else if (millis() - tiempoUmbral >= TIEMPO_SOSTENIDO) {
        bolsaConfirmada = true;
        enviarComando("BOLSA_OK");
        Serial.println("BOLSA_OK enviado");
      }
    } else {
      if (umbralActivo) Serial.println("Umbral perdido");
      umbralActivo = false; tiempoUmbral = 0;
    }
  }

  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim(); cmd.toUpperCase();
    if      (cmd == "VNTON")  encenderBomba();
    else if (cmd == "VNTOFF") apagarBomba();
  }

  static unsigned long lastPrint = 0;
  if (millis() - lastPrint >= 1500) {
    lastPrint = millis();
    Serial.print("Presion: "); Serial.print(pressure, 2); Serial.println(" kPa");
  }
}
