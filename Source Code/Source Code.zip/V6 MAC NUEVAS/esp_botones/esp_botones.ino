// ===== ESP BOTONES =====
#include <WiFi.h>
#include <esp_now.h>

#define BTN1 25   // EMERGENCIA
#define BTN2 26   // INICIAR
#define BTN3 27   // RESET

uint8_t macPesado[] = { 0xA4, 0xF0, 0x0F, 0x73, 0x64, 0x5C };
uint8_t macMosfets[]  = { 0xB0, 0xCB, 0xD8, 0xE8, 0xEF, 0xA0 };
uint8_t macVentosas[] = { 0x3C, 0x71, 0xBF, 0xFD, 0x2E, 0x60 };
uint8_t macCarrito[] = { 0x40, 0x22, 0xD8, 0xEB, 0x42, 0x50 };
uint8_t macNemas[]   = { 0xB0, 0xCB, 0xD8, 0xE9, 0x02, 0x04 };

typedef struct struct_message {
  char comando[16];
} struct_message;
struct_message mensaje;
esp_now_peer_info_t peerInfo;

void enviarComando(uint8_t* mac, const char* cmd) {
  strncpy(mensaje.comando, cmd, sizeof(mensaje.comando));
  mensaje.comando[sizeof(mensaje.comando) - 1] = '\0';
  esp_now_send(mac, (uint8_t *)&mensaje, sizeof(mensaje));
}

void enviarTodos(const char* cmd) {
  enviarComando(macNemas,    cmd);
  enviarComando(macMosfets,  cmd);
  enviarComando(macVentosas, cmd);
  enviarComando(macCarrito,  cmd);
  enviarComando(macPesado,   cmd);
  Serial.print(">> Todos: "); Serial.println(cmd);
}

void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("ACK: ");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "OK" : "FALLO");
}

void agregarPeer(uint8_t* mac) {
  memset(&peerInfo, 0, sizeof(peerInfo));
  memcpy(peerInfo.peer_addr, mac, 6);
  peerInfo.channel = 0; peerInfo.encrypt = false;
  if (esp_now_add_peer(&peerInfo) != ESP_OK) Serial.println("Error peer");
}

void setup() {
  Serial.begin(115200);
  pinMode(BTN1, INPUT);
  pinMode(BTN2, INPUT);
  pinMode(BTN3, INPUT);

  WiFi.mode(WIFI_STA); WiFi.disconnect();
  Serial.println("\n===== ESP BOTONES =====");
  Serial.print("MAC: "); Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) { Serial.println("ERROR ESP-NOW"); return; }
  esp_now_register_send_cb(OnDataSent);

  agregarPeer(macNemas);
  agregarPeer(macMosfets);
  agregarPeer(macVentosas);
  agregarPeer(macCarrito);
  agregarPeer(macPesado);

  Serial.println("Sistema listo.");
  Serial.println("BTN1=EMERGENCIA  BTN2=INICIAR  BTN3=RESET");
}

void leerBotones() {
  if (digitalRead(BTN1)) {
    Serial.println("BTN EMERGENCIA");
    enviarTodos("EMERGENCIA");
    delay(300);
  }
  if (digitalRead(BTN2)) {
    Serial.println("BTN INICIAR");
    enviarComando(macNemas, "INICIAR");
    Serial.println(">> INICIAR -> NEMAS");
    delay(300);
  }
  if (digitalRead(BTN3)) {
    Serial.println("BTN RESET");
    enviarTodos("RESET");
    delay(300);
  }
}

void leerSerial() {
  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim(); cmd.toUpperCase();
    if (cmd.length() == 0) return;
    Serial.print("SERIAL: "); Serial.println(cmd);

    if (cmd == "INICIAR") {
      enviarComando(macNemas, "INICIAR");
      Serial.println("-> Solo NEMAS");
    }
    else if (cmd == "VNTON" || cmd == "VNTOFF") {
      enviarComando(macVentosas, cmd.c_str());
      Serial.println("-> Solo ventosas");
    }
    else if (cmd == "SUBIR" || cmd == "BAJAR" || cmd == "STOP" ||
             cmd == "ABRIR" || cmd == "CERRAR" || cmd == "SEMIABRIR" ||
             cmd == "STEP_DER" || cmd == "STEP_IZQ") {
      enviarComando(macCarrito, cmd.c_str());
      Serial.println("-> Solo carrito");
    }
    else if (cmd == "EMERGENCIA" || cmd == "RESET") {
      enviarTodos(cmd.c_str());
    }
    else {
      int v = cmd.toInt();
      if (v >= 1 && v <= 8) {
        enviarComando(macMosfets, cmd.c_str());
        Serial.println("-> Solo mosfets");
      } else {
        enviarComando(macNemas, cmd.c_str());
        Serial.println("-> NEMAS");
      }
    }
  }
}

void loop() {
  leerBotones();
  leerSerial();
  delay(10);
}