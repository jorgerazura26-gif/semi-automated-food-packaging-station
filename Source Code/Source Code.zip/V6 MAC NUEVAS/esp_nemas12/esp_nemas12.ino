// ===== ESP NEMAS (ORQUESTADOR PRINCIPAL) =====
#include <WiFi.h>
#include <esp_now.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>

// ---------------- MOTOR 1 ----------------
#define STEP  25
#define DIR   33
#define EN    32
#define LS1   34
#define LS2   35

// ---------------- MOTOR 2 ----------------
#define STEP2 13
#define DIR2  14
#define EN2   27
#define LS3   26   // HOME nema2
#define LS4   4    // posicion pesado nema2

// ---------------- MACs ----------------
uint8_t macCarrito[] = { 0x40, 0x22, 0xD8, 0xEB, 0x42, 0x50 };
uint8_t macVentosas[] = { 0x3C, 0x71, 0xBF, 0xFD, 0x2E, 0x60 };
uint8_t macMosfets[]  = { 0xB0, 0xCB, 0xD8, 0xE8, 0xEF, 0xA0 };
uint8_t macPesado[] = { 0xA4, 0xF0, 0x0F, 0x73, 0x64, 0x5C };
uint8_t macBotones[]  = { 0xE0, 0x8C, 0xFE, 0x58, 0x5A, 0xAC };

// ---------------- TIEMPOS ----------------
#define DEBOUNCE_LS      100
#define TIEMPO_INIT      500
#define TIEMPO_ACTUADOR  6000

// ---------------- ESTRUCTURA ----------------
typedef struct struct_message {
  char comando[16];
} struct_message;
struct_message mensajeEnvio;
esp_now_peer_info_t peerInfo;

#define QUEUE_SIZE 8
QueueHandle_t colaComandos;

// ---------------- MOTORES ----------------
int estadoMotor      = 0;
int ultimaDireccion  = 1;
int estadoMotor2     = 0;
int ultimaDireccion2 = 1;
bool ultimoLS1 = LOW, ultimoLS2 = LOW;
bool ultimoLS3 = LOW, ultimoLS4 = LOW;

// ---------------- FLAGS ----------------
bool carritoListo           = false;
bool nema1EnHome            = false;
bool nema2EnHome            = false;   // LS3
bool pesadoSubioActuador    = false;
bool stepDerPendiente       = false;
unsigned long tiempoStepDer = 0;

// ---------------- RESET ----------------
enum EstadoReset {
  RESET_IDLE,
  RESET_RETRAER,
  RESET_ESPERAR_PISTONES,
  RESET_BAJAR_CARRITO,
  RESET_ESPERAR_BAJADA,
  RESET_MOVER_MOTORES
};
EstadoReset estadoReset = RESET_IDLE;
unsigned long tiempoReset = 0;
bool resetMotor1Listo = false;
bool resetMotor2Listo = false;

// ---------------- SECUENCIA ----------------
enum EstadoSecuencia {
  SEQ_IDLE,
  SEQ_NEMA_A_LS1,
  SEQ_VENTOSAS_ON,
  SEQ_NEMA2_A_LS4,          // nema2 moviendose a LS4 (posicion pesado)
  SEQ_ESPERANDO_BOLSA,
  SEQ_RET_VENTOSAS,
  SEQ_ESPERAR_BOMBA_OFF,
  SEQ_ESPERAR_PESADO,
  SEQ_CERRAR_SUBIR,
  SEQ_SUBIENDO,
  SEQ_PRENSA_VACIO,
  SEQ_ESPERAR_ABRIR,
  SEQ_BAJANDO,
  SEQ_SELLADO_INICIO,
  SEQ_ESPERAR_RET_PRENSA,
  SEQ_SELLANDO,
  SEQ_RETRACCION,
  SEQ_NEMA_A_LS2
};
EstadoSecuencia estadoSeq = SEQ_IDLE;
unsigned long tiempoSeq   = 0;

// ===================== PROTOTIPOS =====================
void enviarComando(uint8_t* mac, const char* cmd);
void enviarConReintento(uint8_t* mac, const char* cmd, int n = 2, int ms = 25);
void agregarPeer(uint8_t* mac);
void procesarComando(String comando);
void stepMotor();
void stepMotor2();
void emergencia();

// ===================== CALLBACKS =====================
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {}

void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  char buf[16];
  struct_message tmp;
  memcpy(&tmp, incomingData, sizeof(tmp));
  strncpy(buf, tmp.comando, sizeof(buf));
  buf[15] = '\0';
  for (int i = 0; buf[i]; i++) buf[i] = toupper((unsigned char)buf[i]);
  xQueueSendFromISR(colaComandos, buf, NULL);
}

// ===================== EMERGENCIA =====================
void emergencia() {
  estadoMotor  = 0;
  estadoMotor2 = 0;
  estadoSeq    = SEQ_IDLE;
  estadoReset  = RESET_IDLE;
  pesadoSubioActuador = false;
  stepDerPendiente     = false;
  enviarComando(macCarrito,  "STOP");
  enviarComando(macVentosas, "VNTOFF");
  enviarComando(macMosfets,  "EMERGENCIA");
  enviarComando(macPesado,   "EMERGENCIA");
  Serial.println("===== EMERGENCIA =====");
}

// ===================== ENVIAR =====================
void enviarComando(uint8_t* mac, const char* cmd) {
  strncpy(mensajeEnvio.comando, cmd, sizeof(mensajeEnvio.comando));
  mensajeEnvio.comando[sizeof(mensajeEnvio.comando) - 1] = '\0';
  esp_now_send(mac, (uint8_t *)&mensajeEnvio, sizeof(mensajeEnvio));
  Serial.print("-> "); Serial.println(cmd);
}

void enviarConReintento(uint8_t* mac, const char* cmd, int n, int ms) {
  for (int i = 0; i < n; i++) {
    enviarComando(mac, cmd);
    if (i < n - 1) delay(ms);
  }
}

// ===================== PROCESAR =====================
void procesarComando(String comando) {
  comando.trim();
  comando.toUpperCase();
  Serial.print("CMD: "); Serial.println(comando);

  if (comando == "EMERGENCIA") {
    emergencia();
  }
  else if (comando == "INICIAR") {
    if (estadoSeq != SEQ_IDLE) { Serial.println("Secuencia en curso"); return; }
    if (!carritoListo)  { Serial.println("BLOQUEADO: carrito sin bolsa"); return; }
    if (!nema1EnHome)   { Serial.println("BLOQUEADO: nema1 no en LS2");   return; }

    estadoSeq   = SEQ_NEMA_A_LS1;
    estadoMotor = 1;
    pesadoSubioActuador = false;

    // Enviar INICIAR a pesado para que baje su actuador
    enviarComando(macPesado, "INICIAR");

    // Mover nema2 a LS4 (posicion pesado) si no esta ya ahi
    if (digitalRead(LS4) == HIGH) {
      // Ya esta en LS4, mandar NEMA2_LISTO a pesado directamente
      nema2EnHome = false;
      enviarComando(macPesado, "NEMA2_LISTO");
      Serial.println("Nema2 ya en LS4, NEMA2_LISTO enviado");
    } else {
      // Mover nema2 hacia LS4
      estadoMotor2 = 3;   // DIR hacia LS4
      estadoSeq    = SEQ_NEMA2_A_LS4;
      // Reasignar: nema1 se mueve en paralelo
      estadoSeq   = SEQ_NEMA_A_LS1;   // mantener nema1 moviendose
      Serial.println("Nema2 moviendose a LS4");
    }
    Serial.println("Secuencia iniciada");
  }
  else if (comando == "RESET") {
    if (estadoReset == RESET_IDLE && estadoSeq == SEQ_IDLE) {
      estadoMotor      = 0;
      estadoMotor2     = 0;
      resetMotor1Listo = false;
      resetMotor2Listo = false;
      carritoListo     = false;
      pesadoSubioActuador = false;
      stepDerPendiente     = false;
      estadoReset      = RESET_RETRAER;
      enviarComando(macMosfets,  "RESET");
      enviarComando(macVentosas, "VNTOFF");
      enviarComando(macPesado,   "RESET");
      Serial.println("RESET iniciado");
    } else {
      Serial.println("RESET no disponible ahora");
    }
  }
  else if (comando == "BOLSA_OK") {
    if (estadoSeq == SEQ_ESPERANDO_BOLSA) {
      estadoSeq = SEQ_RET_VENTOSAS;
      Serial.println("BOLSA_OK -> retraer ventosas");
    }
  }
  else if (comando == "CARRITO_LISTO") {
    carritoListo = true;
    Serial.println("Carrito: bolsa sujeta");
  }
  else if (comando == "COMIDA_LISTA") {
    // Comida cayo -> apagar ventosas
    enviarComando(macVentosas, "VNTOFF");
    // 500ms despues mandar STEP_DER a carrito
    stepDerPendiente = true;
    tiempoStepDer    = millis();
    Serial.println("COMIDA_LISTA -> VNTOFF + STEP_DER en 500ms");
  }
  else if (comando == "PESADO_LISTO") {
    pesadoSubioActuador = true;
    // Transicion desde SEQ_ESPERAR_BOMBA_OFF si aun estamos ahi
    if (estadoSeq == SEQ_ESPERAR_BOMBA_OFF) {
      tiempoSeq = millis();
      estadoSeq = SEQ_ESPERAR_PESADO;
    }
    Serial.println("Pesado: actuador subio");
  }
  else if (comando == "SUBIR")     { enviarComando(macCarrito, "SUBIR"); }
  else if (comando == "BAJAR")     { enviarComando(macCarrito, "BAJAR"); }
  else if (comando == "STOP")      { enviarComando(macCarrito, "STOP");  }
  else if (comando == "ABRIR")     { enviarComando(macCarrito, "ABRIR"); }
  else if (comando == "CERRAR")    { enviarComando(macCarrito, "CERRAR"); }
  else if (comando == "SEMIABRIR") { enviarComando(macCarrito, "SEMIABRIR"); }
  else if (comando == "MOVER")     { estadoMotor  = ultimaDireccion; }
  else if (comando == "MOVER2")    { estadoMotor2 = ultimaDireccion2; }
  else if (comando == "VNTON")     { enviarComando(macVentosas, "VNTON"); }
  else if (comando == "VNTOFF")    { enviarComando(macVentosas, "VNTOFF"); }
}

// ===================== AGREGAR PEER =====================
void agregarPeer(uint8_t* mac) {
  memset(&peerInfo, 0, sizeof(peerInfo));
  memcpy(peerInfo.peer_addr, mac, 6);
  peerInfo.channel = 0; peerInfo.encrypt = false;
  if (esp_now_add_peer(&peerInfo) != ESP_OK) Serial.println("Error peer");
}

// ===================== SETUP =====================
void setup() {
  Serial.begin(115200);
  colaComandos = xQueueCreate(QUEUE_SIZE, 16);

  pinMode(STEP,  OUTPUT); pinMode(DIR,  OUTPUT); pinMode(EN,  OUTPUT);
  pinMode(STEP2, OUTPUT); pinMode(DIR2, OUTPUT); pinMode(EN2, OUTPUT);
  digitalWrite(EN, LOW); digitalWrite(EN2, LOW);
  pinMode(LS1, INPUT); pinMode(LS2, INPUT);
  pinMode(LS3, INPUT); pinMode(LS4, INPUT);

  WiFi.mode(WIFI_STA); WiFi.disconnect();
  Serial.print("MAC NEMAS: "); Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) { Serial.println("Error ESP-NOW"); return; }
  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);

  agregarPeer(macCarrito);
  agregarPeer(macVentosas);
  agregarPeer(macMosfets);
  agregarPeer(macPesado);
  agregarPeer(macBotones);

  // Verificar posiciones al arrancar
  if (digitalRead(LS2) == HIGH) { nema1EnHome = true; Serial.println("Nema1 en HOME (LS2)"); }
  if (digitalRead(LS3) == HIGH) { nema2EnHome = true; Serial.println("Nema2 en HOME (LS3)"); }

  Serial.println("ESP NEMAS lista.");
}

// ===================== LOOP =====================
void loop() {

  char bufCmd[16];
  while (xQueueReceive(colaComandos, bufCmd, 0) == pdTRUE) {
    procesarComando(String(bufCmd));
  }

  bool ls1 = digitalRead(LS1);
  bool ls2 = digitalRead(LS2);
  bool ls3 = digitalRead(LS3);
  bool ls4 = digitalRead(LS4);

  // ---------- LS1 ----------
  if (ultimoLS1 == LOW && ls1 == HIGH) {
    delay(DEBOUNCE_LS);
    if (digitalRead(LS1) == HIGH && estadoMotor == 1) {
      estadoMotor     = 0;
      ultimaDireccion = 3;
      nema1EnHome     = false;
      if (estadoReset == RESET_MOVER_MOTORES) {
        resetMotor1Listo = true;
        Serial.println("Motor1 en LS1");
      } else if (estadoSeq == SEQ_NEMA_A_LS1) {
        // Activar ventosas
        enviarConReintento(macMosfets,  "2", 2, 25);
        delay(25);
        enviarComando(macVentosas, "VNTON");
        delay(25);
        enviarComando(macCarrito,  "SEMIABRIR");
        tiempoSeq = millis();
        estadoSeq = SEQ_ESPERANDO_BOLSA;
        Serial.println("LS1: ventosas ON, semiabrir");
      }
    }
  }

  // ---------- LS2 ----------
  if (ultimoLS2 == LOW && ls2 == HIGH) {
    delay(DEBOUNCE_LS);
    if (digitalRead(LS2) == HIGH && estadoMotor == 3) {
      estadoMotor     = 0;
      ultimaDireccion = 1;
      nema1EnHome     = true;
      if (estadoReset == RESET_MOVER_MOTORES) {
        resetMotor1Listo = true;
        Serial.println("Motor1 en LS2 (HOME)");
      } else if (estadoSeq == SEQ_NEMA_A_LS2) {
        enviarComando(macCarrito, "STEP_IZQ");
        estadoSeq = SEQ_IDLE;
        Serial.println("Secuencia completa. Nema1 en HOME. STEP_IZQ a carrito.");
      }
    }
  }

  // ---------- LS3 = HOME nema2 ----------
  if (ultimoLS3 == LOW && ls3 == HIGH) {
    delay(DEBOUNCE_LS);
    if (digitalRead(LS3) == HIGH && estadoMotor2 == 1) {
      estadoMotor2     = 0;
      ultimaDireccion2 = 3;
      nema2EnHome      = true;
      if (estadoReset == RESET_MOVER_MOTORES) {
        resetMotor2Listo = true;
        Serial.println("Motor2 en HOME (LS3)");
      }
      // En secuencia normal llegar a LS3 no hace nada especial
      // LS3 es solo home, la posicion activa es LS4
    }
  }

  // ---------- LS4 = posicion pesado nema2 ----------
  if (ultimoLS4 == LOW && ls4 == HIGH) {
    delay(DEBOUNCE_LS);
    if (digitalRead(LS4) == HIGH && estadoMotor2 == 3) {
      estadoMotor2     = 0;
      ultimaDireccion2 = 1;
      nema2EnHome      = false;
      if (estadoReset == RESET_MOVER_MOTORES) {
        resetMotor2Listo = true;
        Serial.println("Motor2 en LS4");
      } else {
        // Nema2 llego a posicion de pesado -> avisar a pesado
        enviarComando(macPesado, "NEMA2_LISTO");
        Serial.println("Nema2 en LS4 (pesado). NEMA2_LISTO enviado.");
      }
    }
  }

  ultimoLS1 = ls1; ultimoLS2 = ls2;
  ultimoLS3 = ls3; ultimoLS4 = ls4;

  // ===================== MAQUINA SECUENCIA =====================
  switch (estadoSeq) {

    case SEQ_RET_VENTOSAS:
      enviarConReintento(macMosfets, "1", 2, 25);  // retraer pistones ventosas
      enviarComando(macPesado, "BOLSA_ABIERTA");
      tiempoSeq = millis();
      estadoSeq = SEQ_ESPERAR_BOMBA_OFF;
      Serial.println("Ventosas retraidas. BOLSA_ABIERTA a pesado.");
      break;

    case SEQ_ESPERAR_BOMBA_OFF:
      // 1s despues de retraer pistones -> cerrar pinzas
      if (millis() - tiempoSeq >= 1000) {
        enviarComando(macCarrito, "CERRAR");
        Serial.println("Pinzas cerradas (1s tras retraer ventosas)");
      }
      // Ventosas se apagan cuando llega COMIDA_LISTA desde pesado (no con timer)
      // La transicion a SEQ_ESPERAR_PESADO la hace procesarComando al recibir PESADO_LISTO
      break;

    case SEQ_ESPERAR_PESADO:
      if (pesadoSubioActuador) {
        pesadoSubioActuador = false;
        enviarComando(macCarrito, "CERRAR");
        // Nema2 regresa a home (LS3)
        estadoMotor2 = 1;
        tiempoSeq    = millis();
        estadoSeq    = SEQ_CERRAR_SUBIR;
        Serial.println("Pesado listo: cerrando pinzas, nema2 a LS3");
      }
      break;

    case SEQ_CERRAR_SUBIR:
      // 500ms para cerrar pinzas, luego STEP_DER a los 500ms, luego 3s mas antes de SUBIR
      // Total: 3500ms desde PESADO_LISTO hasta SUBIR
      if (millis() - tiempoSeq >= 3500) {
        enviarComando(macCarrito, "SUBIR");
        tiempoSeq = millis();
        estadoSeq = SEQ_SUBIENDO;
        Serial.println("SUBIR pinzas");
      }
      break;

    case SEQ_SUBIENDO:
      if (millis() - tiempoSeq >= 10000) {
        enviarConReintento(macMosfets, "3", 2, 25);  // EXT_PRENSA_VACIO
        delay(25);
        enviarConReintento(macMosfets, "7", 2, 25);  // SELLADO_TERMICO junto con prensa vacio
        tiempoSeq = millis();
        estadoSeq = SEQ_PRENSA_VACIO;
        Serial.println("EXT_PRENSA_VACIO + SELLADO_TERMICO");
      }
      break;

    case SEQ_PRENSA_VACIO:
      if (millis() - tiempoSeq >= 1000) {
        enviarComando(macCarrito, "ABRIR");
        tiempoSeq = millis();
        estadoSeq = SEQ_ESPERAR_ABRIR;
        Serial.println("ABRIR pinzas");
      }
      break;

    case SEQ_ESPERAR_ABRIR:
      if (millis() - tiempoSeq >= 300) {
        enviarComando(macCarrito, "BAJAR");
        tiempoSeq = millis();
        estadoSeq = SEQ_BAJANDO;
        Serial.println("BAJAR pinzas");
      }
      break;

    case SEQ_BAJANDO:
      // A los 6s de bajar -> EXT_SELLADO (mosfet ya prendido desde SEQ_SUBIENDO)
      if (millis() - tiempoSeq >= 6000) {
        enviarConReintento(macMosfets, "6", 2, 25);  // EXT_SELLADO
        tiempoSeq = millis();
        estadoSeq = SEQ_SELLADO_INICIO;
        Serial.println("EXT_SELLADO");
      }
      break;

    case SEQ_SELLADO_INICIO:
      // No usado: caer directo a SEQ_SELLANDO
      estadoSeq = SEQ_SELLANDO;
      break;

    case SEQ_SELLANDO:
      // 14s desde EXT_SELLADO -> retraer piston vacio y sellado simultaneamente
      if (millis() - tiempoSeq >= 23000) {
        enviarConReintento(macMosfets, "4", 2, 25);  // RET_PRENSA_VACIO
        delay(25);
        enviarConReintento(macMosfets, "5", 2, 25);  // RET_SELLADO
        tiempoSeq = millis();
        estadoSeq = SEQ_RETRACCION;
        Serial.println("RET_PRENSA_VACIO + RET_SELLADO simultaneos");
      }
      break;

    case SEQ_RETRACCION:
      if (millis() - tiempoSeq >= 2000) {
        estadoMotor = 3;
        estadoSeq   = SEQ_NEMA_A_LS2;
        Serial.println("Motor1 a HOME (LS2)");
      }
      break;

    default: break;
  }

  // ===================== MAQUINA RESET =====================
  switch (estadoReset) {

    case RESET_RETRAER:
      tiempoReset = millis();
      estadoReset = RESET_ESPERAR_PISTONES;
      break;

    case RESET_ESPERAR_PISTONES:
      if (millis() - tiempoReset >= TIEMPO_INIT) {
        enviarComando(macCarrito, "BAJAR");
        tiempoReset = millis();
        estadoReset = RESET_BAJAR_CARRITO;
        Serial.println("Bajando pinzas (6s)...");
      }
      break;

    case RESET_BAJAR_CARRITO:
      if (millis() - tiempoReset >= 6000) {
        tiempoReset = millis();
        estadoReset = RESET_ESPERAR_BAJADA;
      }
      break;

    case RESET_ESPERAR_BAJADA:
      if (millis() - tiempoReset >= 500) {
        resetMotor1Listo = false;
        resetMotor2Listo = false;
        if (digitalRead(LS2) == HIGH) {
          resetMotor1Listo = true;
          nema1EnHome = true;
          Serial.println("Motor1 ya en LS2");
        } else {
          estadoMotor = 3;
          Serial.println("Motor1 hacia LS2");
        }
        if (digitalRead(LS3) == HIGH) {
          resetMotor2Listo = true;
          nema2EnHome = true;
          Serial.println("Motor2 ya en LS3");
        } else {
          estadoMotor2 = 1;
          Serial.println("Motor2 hacia LS3");
        }
        estadoReset = RESET_MOVER_MOTORES;
      }
      break;

    case RESET_MOVER_MOTORES:
      if (resetMotor1Listo && resetMotor2Listo) {
        estadoMotor  = 0;
        estadoMotor2 = 0;
        estadoReset  = RESET_IDLE;
        nema1EnHome  = true;
        nema2EnHome  = true;
        Serial.println("RESET completo");
      }
      break;

    default: break;
  }

  // Mandar STEP_DER a carrito 500ms despues de COMIDA_LISTA
  if (stepDerPendiente && millis() - tiempoStepDer >= 500) {
    enviarComando(macCarrito, "STEP_DER");
    stepDerPendiente = false;
    Serial.println("STEP_DER enviado a carrito");
  }

  if (Serial.available()) {
    String comando = Serial.readStringUntil('\n');
    procesarComando(comando);
  }

  if (estadoMotor == 1)      { digitalWrite(DIR, HIGH); stepMotor(); }
  else if (estadoMotor == 3) { digitalWrite(DIR, LOW);  stepMotor(); }
  if (estadoMotor2 == 1)      { digitalWrite(DIR2, HIGH); stepMotor2(); }
  else if (estadoMotor2 == 3) { digitalWrite(DIR2, LOW);  stepMotor2(); }

  if (estadoMotor == 0 && estadoMotor2 == 0) vTaskDelay(1);
}

void stepMotor()  { digitalWrite(STEP,  HIGH); delayMicroseconds(80); digitalWrite(STEP,  LOW); delayMicroseconds(80); }
void stepMotor2() { digitalWrite(STEP2, HIGH); delayMicroseconds(80); digitalWrite(STEP2, LOW); delayMicroseconds(80); }