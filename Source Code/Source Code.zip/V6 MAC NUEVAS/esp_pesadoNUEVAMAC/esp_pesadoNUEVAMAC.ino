// ===== ESP PESADO =====
#include "HX711.h"
#include <ESP32Servo.h>
#include <WiFi.h>
#include <esp_now.h>

// --- Pines ---
#define DT       4
#define SCK      5
#define AIN1    16
#define AIN2    17
#define PWMA    18
#define STBY    19
#define STEP_PIN 26
#define DIR_PIN  27
#define ENA_PIN  14
#define SERVO_PIN 25

// --- MACs ---
uint8_t macNemas[] = { 0xB0, 0xCB, 0xD8, 0xE9, 0x02, 0x04 };

typedef struct struct_message {
  char comando[16];
} struct_message;
struct_message mensajeEnvio;
struct_message mensajeRecibido;
esp_now_peer_info_t peerInfo;

HX711 scale;
Servo servo;

float ultimo_peso_valido  = 0.0;
unsigned long ultima_lectura = 0;
float pesoObjetivo = 100.0;
float Kp = 6, Kd = 20;
float umbralPD = 10.0;
float errorAnterior      = 0.0;
unsigned long tiempoAnteriorPD = 0;

// --- Estado ---
enum EstadoPesado {
  PES_IDLE,
  PES_BAJANDO_ACTUADOR,
  PES_ESPERANDO_NEMA2,
  PES_DISPENSANDO,
  PES_ESPERANDO_BOLSA,
  PES_ABRIENDO_SERVO,
  PES_SERVO_ABIERTO,
  PES_SUBIENDO_ACTUADOR,
  PES_RESET_SUBIENDO,
  PES_LISTO
};
EstadoPesado estadoPesado = PES_IDLE;
unsigned long tiempoPesado = 0;

bool nema_girando  = false;
bool step_state    = false;
bool pesoAlcanzado = false;
bool bolsaAbierta  = false;
bool nema2Listo    = false;

// Tara inteligente
bool servoSeAbrio = true;

// Apertura gradual del servo
int servoPos           = 135;
const int servoCerrado = 135;
const int servoAbierto = 80;
unsigned long tiempoUltimoPasoServo = 0;
const int pasoServo  = 1;
const int delayServo = 90;

// Vibracion / agitacion
#define INTERVALO_VIBRA  800
#define DURACION_VIBRA   300
#define PERIODO_MAX      667
bool   vibrando          = false;
unsigned long tiempoVibra = 0;

// --- Timer NEMA23 ---
hw_timer_t *timer = NULL;
portMUX_TYPE timerMux = portMUX_INITIALIZER_UNLOCKED;

void IRAM_ATTR onTimer() {
  portENTER_CRITICAL_ISR(&timerMux);
  if (nema_girando) { step_state = !step_state; digitalWrite(STEP_PIN, step_state); }
  portEXIT_CRITICAL_ISR(&timerMux);
}

// --- Actuador lineal ---
void motorApagado() {
  digitalWrite(STBY, LOW); digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, LOW); analogWrite(PWMA, 0);
}
void iniciarSubida() {
  digitalWrite(STBY, HIGH); digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, HIGH); analogWrite(PWMA, 255);
}
void iniciarBajada() {
  digitalWrite(STBY, HIGH); digitalWrite(AIN1, HIGH);
  digitalWrite(AIN2, LOW);  analogWrite(PWMA, 255);
}

// --- Control PD ---
void actualizarControlPD(float pesoActual) {
  float error = pesoObjetivo - pesoActual;
  unsigned long ahora = millis();
  float dt = (ahora - tiempoAnteriorPD) / 1000.0;
  if (dt <= 0) return;
  float derivada = (error - errorAnterior) / dt;
  float salida   = Kp * error + Kd * derivada;
  errorAnterior    = error;
  tiempoAnteriorPD = ahora;
  salida = constrain(salida, 50, 1000);
  uint32_t periodo_us = map((int)salida, 50, 1000, 4000, PERIODO_MAX);
  timerAlarmWrite(timer, periodo_us, true);
}

// --- Apertura gradual del servo ---
void iniciarAperturaServo() {
  servoPos     = servoCerrado;
  servoSeAbrio = true;
  servo.write(servoPos);
  tiempoUltimoPasoServo = millis();
  estadoPesado = PES_ABRIENDO_SERVO;
  Serial.println("Abriendo servo gradualmente...");
}

// --- Arrancar dispensacion ---
void iniciarDispensacion() {
  estadoPesado     = PES_DISPENSANDO;
  errorAnterior    = pesoObjetivo;
  tiempoAnteriorPD = millis();
  timerAlarmWrite(timer, PERIODO_MAX, true);
  digitalWrite(ENA_PIN, LOW);
  nema_girando  = true;
  vibrando      = false;
  tiempoVibra   = millis();
  Serial.println("Dispensando: nema23 ON");
}

// --- Enviar a NEMAS ---
void enviarComando(const char* cmd) {
  strncpy(mensajeEnvio.comando, cmd, sizeof(mensajeEnvio.comando));
  mensajeEnvio.comando[sizeof(mensajeEnvio.comando) - 1] = '\0';
  esp_now_send(macNemas, (uint8_t *)&mensajeEnvio, sizeof(mensajeEnvio));
  Serial.print("-> NEMAS: "); Serial.println(cmd);
}

// --- Callbacks ---
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {}

void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  memcpy(&mensajeRecibido, incomingData, sizeof(mensajeRecibido));
  String cmd = String(mensajeRecibido.comando);
  cmd.trim(); cmd.toUpperCase();
  Serial.print("Recibido: "); Serial.println(cmd);

  if (cmd == "INICIAR") {
    if (estadoPesado == PES_IDLE || estadoPesado == PES_LISTO) {
      iniciarBajada();
      tiempoPesado  = millis();
      estadoPesado  = PES_BAJANDO_ACTUADOR;
      pesoAlcanzado = false;
      bolsaAbierta  = false;
      nema_girando  = false;
      nema2Listo    = false;
      Serial.println("INICIAR: bajando actuador");
    }
  }
  else if (cmd == "NEMA2_LISTO") {
    Serial.println("NEMA2_LISTO recibido");
    if (servoSeAbrio) {
      scale.tare();
      servoSeAbrio = false;
      Serial.println("Tara ejecutada (ciclo anterior completo)");
    } else {
      Serial.println("Sin tara: conservando peso acumulado");
    }
    if (estadoPesado == PES_ESPERANDO_NEMA2) {
      iniciarDispensacion();
    } else if (estadoPesado == PES_BAJANDO_ACTUADOR) {
      nema2Listo = true;
      Serial.println("NEMA2_LISTO guardado (actuador aun bajando)");
    }
  }
  else if (cmd == "BOLSA_ABIERTA") {
    bolsaAbierta = true;
    Serial.println("Bolsa abierta confirmada");
    if (estadoPesado == PES_ESPERANDO_BOLSA) {
      iniciarAperturaServo();
      Serial.println("Iniciando apertura servo");
    }
  }
  else if (cmd == "EMERGENCIA") {
    nema_girando = false;
    vibrando     = false;
    digitalWrite(DIR_PIN, LOW);
    digitalWrite(ENA_PIN, HIGH);
    motorApagado();
    servo.write(135);
    estadoPesado = PES_IDLE;
    nema2Listo   = false;
    Serial.println("EMERGENCIA");
  }
  else if (cmd == "RESET") {
    nema_girando = false;
    vibrando     = false;
    digitalWrite(DIR_PIN, LOW);
    digitalWrite(ENA_PIN, HIGH);
    servo.write(135);
    pesoAlcanzado = false;
    bolsaAbierta  = false;
    nema2Listo    = false;
    iniciarSubida();
    tiempoPesado = millis();
    estadoPesado = PES_RESET_SUBIENDO;
    Serial.println("RESET pesado: subiendo actuador");
  }
}

void agregarPeer(uint8_t* mac) {
  memset(&peerInfo, 0, sizeof(peerInfo));
  memcpy(peerInfo.peer_addr, mac, 6);
  peerInfo.channel = 0; peerInfo.encrypt = false;
  esp_now_add_peer(&peerInfo);
}

// ===================== SETUP =====================
void setup() {
  Serial.begin(115200);

  scale.begin(DT, SCK);
  scale.set_scale(355.34);
  delay(2000);
  scale.tare();
  Serial.println("Tara inicial lista");

  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(PWMA, OUTPUT); pinMode(STBY, OUTPUT);
  motorApagado();

  pinMode(STEP_PIN, OUTPUT); pinMode(DIR_PIN, OUTPUT); pinMode(ENA_PIN, OUTPUT);
  digitalWrite(DIR_PIN, LOW); digitalWrite(STEP_PIN, LOW);
  digitalWrite(ENA_PIN, HIGH);

  servo.attach(SERVO_PIN);
  servo.write(135);

  timer = timerBegin(0, 80, true);
  timerAttachInterrupt(timer, &onTimer, true);
  timerAlarmWrite(timer, 2000, true);
  timerAlarmEnable(timer);

  WiFi.mode(WIFI_STA); WiFi.disconnect();
  Serial.print("MAC PESADO: "); Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) { Serial.println("Error ESP-NOW"); return; }
  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);
  agregarPeer(macNemas);

  Serial.println("ESP PESADO lista. Esperando INICIAR...");
}

// ===================== LOOP =====================
void loop() {

  // --- Vibracion (solo en PES_DISPENSANDO, fuera de zona PD) ---
  if (estadoPesado == PES_DISPENSANDO && nema_girando) {
    bool enZonaPD = (ultimo_peso_valido >= (pesoObjetivo - umbralPD));
    if (!enZonaPD) {
      if (!vibrando) {
        if (millis() - tiempoVibra >= INTERVALO_VIBRA) {
          vibrando    = true;
          tiempoVibra = millis();
          digitalWrite(DIR_PIN, HIGH);
          timerAlarmWrite(timer, PERIODO_MAX, true);
          Serial.println("Vibrando...");
        }
      } else {
        if (millis() - tiempoVibra >= DURACION_VIBRA) {
          vibrando    = false;
          tiempoVibra = millis();
          digitalWrite(DIR_PIN, LOW);
          timerAlarmWrite(timer, PERIODO_MAX, true);
          Serial.println("Fin vibra");
        }
      }
    } else {
      if (vibrando) {
        vibrando = false;
        digitalWrite(DIR_PIN, LOW);
      }
    }
  }

  switch (estadoPesado) {

    case PES_BAJANDO_ACTUADOR:
      if (millis() - tiempoPesado >= 9200) {
        motorApagado();
        if (nema2Listo) {
          nema2Listo = false;
          Serial.println("Actuador abajo. NEMA2 ya estaba listo -> dispensando");
          iniciarDispensacion();
        } else {
          estadoPesado = PES_ESPERANDO_NEMA2;
          Serial.println("Actuador abajo. Esperando NEMA2_LISTO...");
        }
      }
      break;

    case PES_DISPENSANDO:
      if (millis() - ultima_lectura >= 200) {
        ultima_lectura = millis();
        if (scale.is_ready()) {
          float peso = scale.get_units(1);
          if (peso < 0) peso = 0.0;
          ultimo_peso_valido = peso;
          Serial.print("Peso: "); Serial.print(peso, 1); Serial.println(" g");

          if (peso >= (pesoObjetivo - umbralPD)) {
            actualizarControlPD(peso);
          } else {
            errorAnterior    = pesoObjetivo - peso;
            tiempoAnteriorPD = millis();
            timerAlarmWrite(timer, PERIODO_MAX, true);
          }

          if (peso >= pesoObjetivo && !pesoAlcanzado) {
            pesoAlcanzado = true;
            nema_girando  = false;
            vibrando      = false;
            digitalWrite(DIR_PIN,  LOW);
            digitalWrite(STEP_PIN, LOW);
            digitalWrite(ENA_PIN,  HIGH);
            Serial.println("Peso objetivo alcanzado");

            if (bolsaAbierta) {
              iniciarAperturaServo();
              Serial.println("Iniciando apertura servo (bolsa ya estaba abierta)");
            } else {
              estadoPesado = PES_ESPERANDO_BOLSA;
              Serial.println("Esperando BOLSA_ABIERTA...");
            }
          }
        }
      }
      break;

    case PES_ABRIENDO_SERVO:
      if (millis() - tiempoUltimoPasoServo >= delayServo) {
        tiempoUltimoPasoServo = millis();
        if (servoPos > servoAbierto) {
          servoPos -= pasoServo;
          servo.write(servoPos);
        } else {
          servoPos = servoAbierto;
          servo.write(servoPos);
          tiempoPesado = millis();
          estadoPesado = PES_SERVO_ABIERTO;
          Serial.println("Servo completamente abierto");
        }
      }
      break;

    case PES_SERVO_ABIERTO:
      if (millis() - tiempoPesado >= 5000) {
        servo.write(135);
        iniciarSubida();
        tiempoPesado = millis();
        estadoPesado = PES_SUBIENDO_ACTUADOR;
        enviarComando("COMIDA_LISTA");
        enviarComando("PESADO_LISTO");
        Serial.println("Comida caida: COMIDA_LISTA + PESADO_LISTO enviados. Subiendo actuador.");
      }
      break;

    case PES_SUBIENDO_ACTUADOR:
      if (millis() - tiempoPesado >= 9000) {
        motorApagado();
        estadoPesado = PES_LISTO;
        Serial.println("Actuador arriba. Ciclo pesado completo.");
      }
      break;

    case PES_RESET_SUBIENDO:
      if (millis() - tiempoPesado >= 10000) {
        motorApagado();
        estadoPesado = PES_IDLE;
        Serial.println("Actuador arriba (reset). Listo.");
      }
      break;

    case PES_LISTO:
      break;

    default: break;
  }

  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim(); cmd.toUpperCase();
    if      (cmd == "TARA") { scale.tare(); Serial.println("Tara manual"); }
    else if (cmd == "PESO") {
      if (scale.is_ready()) {
        Serial.print("Peso: "); Serial.print(scale.get_units(5), 1); Serial.println(" g");
      }
    }
  }
}
